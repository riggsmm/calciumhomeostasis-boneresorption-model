
ca.bone.cmt <- function(){
  c(
    "PTH",
    "S",
    "PTmax",
    "B",
    "SC",
    "A",
    "P",
    "ECCPhos",
    "T",
    "R",
    "HAp",
    "OBfast",
    "OBslow",
    "PhosGut",
    "IntraPO",
    "OC",
    "ROB1",
    "TGFB",
    "TGFBact",
    "L",
    "RNK",
    "M",
    "N",
    "O",
    "Q",
    "Qbone",
    "RX2",
    "CREB",
    "BCL2",
    "TERISC"
  
    )
}
  
